(function( window, $, wp ) {

  var jobifyCustomizer = jobifyCustomizer || {};

  $(document).on( 'ready', function() {
  });

})( this, jQuery, wp );
