<?php
/**
 * Geo My WordPress integration.
 *
 * @package Jobify
 * @category Integration
 * @since Jobify 3.0.0
 */
class Jobify_Geo_My_WP extends Jobify_Integration {

	public function __construct() {
		parent::__construct( dirname( __FILE__) );
	}

}
